import WalletProviderModal from './WalletProviderModal';

export default WalletProviderModal;
