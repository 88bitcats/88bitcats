export { default } from './Miniland';
