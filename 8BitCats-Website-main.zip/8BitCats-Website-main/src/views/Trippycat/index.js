export { default } from './Trippycat';
