export { default } from './Miniguinea';
