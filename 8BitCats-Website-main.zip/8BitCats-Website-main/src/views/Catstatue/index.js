export { default } from './Catstatue';
