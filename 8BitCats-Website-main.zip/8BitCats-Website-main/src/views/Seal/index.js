export { default } from './Seal';
