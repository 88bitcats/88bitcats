export { default } from './Stone';
