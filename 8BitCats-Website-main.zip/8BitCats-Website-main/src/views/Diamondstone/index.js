export { default } from './Diamondstone';
