export { default } from './Minichilla';
