export { default } from './Info';

      